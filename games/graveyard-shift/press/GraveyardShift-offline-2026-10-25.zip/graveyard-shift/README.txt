GRAVE HOG'S GRAVEYARD SHIFT  (Early Access / 早期アクセス版)
by Spacetrucker / THE JURN   https://thejurn.com   X: @Spacetrucker138

[English]
HOW TO PLAY: Open index.html in Chrome, Edge or Firefox (works offline, no install).
Choose the PC or Mobile version.
CONTROLS: WASD / Arrow keys move, mouse wheel zoom, M map, ESC pause,
Enter / Space / Right arrow = next panel. Weapons fire automatically.
Level-up: 1/2/3 pick a card, R reroll, B banish.
Controller: left stick/D-pad move, Start pause, Back map, A pick, B back, X reroll, Y banish.
P = photo freeze. Progress is saved in your browser.
Stage 1: survive the night and beat the Cemetery King. Stage 2 (Mega Mart): beat Produce Horror, Cart Beast and the Meat Manager.

[日本語]
遊び方：index.html を Chrome / Edge / Firefox で開いてください（オフラインで動作、インストール不要）。
PC版またはスマホ版を選んでください。
操作：WASD / 矢印キーで移動、マウスホイールでズーム、M でマップ、ESC でポーズ、
Enter / Space / → で次へ。武器は自動で攻撃します。
レベルアップ：1/2/3 でカード選択、R でリロール、B でバニッシュ。
コントローラー：左スティック/十字キーで移動、Start ポーズ、Back マップ、A 決定、B 戻る、X リロール、Y バニッシュ。
P = 写真用一時停止。進行状況はブラウザに保存されます。
ステージ1：夜を生き延び、墓地の王（Cemetery King）を倒そう。ステージ2（メガマート）：Produce Horror、Cart Beast、Meat Manager を倒そう。

Credits / クレジット: Spacetrucker / THE JURN
© Spacetrucker / THE JURN
